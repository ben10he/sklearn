def test_median_in_filters():
    from skimage.filters import median
